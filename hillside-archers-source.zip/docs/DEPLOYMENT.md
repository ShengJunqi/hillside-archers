# 免费备用入口与离线分享

游戏不需要服务器程序、外部字体服务、模型 API 或 ChatGPT 登录。把 `dist/` 中的文件完整放在静态网站根目录即可；页面和模块使用相对路径，也能放在 `/hillside-archers/` 子目录。

## GitHub Pages

已准备独立的 `gh-pages` 发布分支：入口是根目录 `index.html`，包含全部模块、样式、离线 HTML 和 `.nojekyll`。业务开发继续使用功能分支和 PR，不要在发布分支编辑源码。

本仓库已启用 GitHub Pages。其他仓库首次启用时，由所有者完成：

1. 打开 https://github.com/ShengJunqi/hillside-archers/settings/pages 。
2. Source 选择 **Deploy from a branch**。
3. Branch 选择 **gh-pages**，目录选择 **/(root)**，点击 **Save**。
4. 等待 Pages 构建成功，访问设置页给出的链接。

已发布地址为 https://shengjunqi.github.io/hillside-archers/ 。GitHub Pages 是免费海外备用入口；并非中国大陆托管，也没有中国大陆稳定访问保证。应请目标玩家用当地网络实测。

GitHub 集成可能缺少开启 Pages 所需的管理权限。此仓库首次创建 API 曾返回 403，由所有者在设置页启用后已正常发布；不需要提供密码、令牌或付费。

后续发布应先在源码分支完成 `npm run build`、`npm test`，提交源码和离线文件，再将该提交的 `dist/` 内容复制到 `gh-pages` 根目录。仅推送源码功能分支不会自动更新备用站。

## 进度迁移

不同网址的浏览器存档互不共享。原站旅营点击「迁移进度」，复制 `HA2:` 代码，在新站旅营粘贴导入。

代码包含章节、模式解锁、纪录、余烬、永久修行和自定义弓手名字。两边按较高进度合并，重复导入不会叠加余烬；本地已有自定义名字时保留本地名字，仍为默认名字的位置可使用导入的名字。进行中的远征、临时遗物和当前对局不跨站迁移。

## 不联网的分享方式

下载 `dist/download.html` 后可直接发给朋友，用浏览器打开。它内联所有代码与样式，不依赖原站或 GitHub 在当地能否访问。离线版同样支持手机／电脑切换和进度迁移；文件来源的浏览器存档行为可能因系统而异，换设备前可先复制迁移代码。

如以后需要中国大陆稳定低延迟入口，再使用具有相应账号和域名的国内托管，并按托管服务要求配置域名；当前没有购买任何域名或托管服务。

## 可选账号云存档

在线发布前，在当前开发机的 `.env.local` 填好已有 CloudBase 环境的 Publishable Key，再运行 `npm run build`。将生成的 `dist/cloud-config.json` 与整个 `dist/` 一同打包到原站和 Pages 分支；这个生成文件被 Git 忽略，不会随源码 PR 自动到达网站。不要将 `.env.local` 或任何管理 API Key 放进站点。

未配置时游戏仍可本机游玩，账号弹窗提示本站暂未配置。`download.html` 始终是完全离线版本，不载入 SDK 或云配置。新增站点域名时需同步 CloudBase 安全来源；现有两个游戏域名已添加。参见 [账号存档说明](ACCOUNT_SAVES.md)。

## 0.12.1 账号密码测试发布

- 原站已发布为 Sites 第 15 版，部署工具返回 `succeeded`：https://hillside-archers-first-duel.soundhorse9.chatgpt.site 。源码提交为 `44df5d8a77d7b298f9105fb8975dffae7480b095`；保留公开访问方式及原有协作提示词／源码 ZIP 下载。
- 备用站已发布 `gh-pages` 提交 `d51c418839ecd75c82f47e140e970264e8ad74f0`：https://shengjunqi.github.io/hillside-archers/ 。[Pages 构建](https://github.com/ShengJunqi/hillside-archers/actions/runs/42671999913)成功。
- 已核对备用站的页面、两个账号模块、云配置及浏览器 SDK 共五个文件，与本机已验证构建的摘要一致；模块返回 JavaScript MIME。两个站点来源的 CloudBase API 跨域响应已核对，未登录访问被拒绝。
- 当前执行环境的原站 HTTP 探测收到 Cloudflare `1010` 拒绝，因此原站只确认原生发布工具成功，未独立复核页面。真实浏览器／手机登录与邮箱收码仍待玩家实测；DOM 表单验证不等同于浏览器验收。

## 0.13.0 原创画面与特效发布

原站已发布 Sites 第 16 版，原生发布工具返回 succeeded，静态源码提交 `c24dc8d690c5a7c8b1c3cd69da1d55bf358b6d71`。备用站发布 `gh-pages` 提交 `5f42223fa87ea1796338d2b69bc2da3d2ea6f33c`，Actions 构建成功：https://github.com/ShengJunqi/hillside-archers/actions/runs/43379808039 。

已按 SHA-256 比对备用站 render.mjs、download.html、index.html 与本机构建，结果一致；DeepSeek 提示词下载与文档字节一致。原有协作提示词及源码 ZIP 继续保留。1160 项检查及离线构建通过，三图／角色／元素效果已用原生 Canvas 出图检查；真实浏览器和手机性能仍待实测。

手动协作提示词：https://shengjunqi.github.io/hillside-archers/deepseek-art-prompt.txt 。当前会话没有调用 DeepSeek harness，没有增加游戏运行时 AI 请求或服务费用。

## 0.14.0 荒诞漫画巡回赛发布

- 游戏源码：`7f25f5cc5c0e5eb8ab26830edef24e40c9a7badd`，PR：https://github.com/ShengJunqi/hillside-archers/pull/10 。基于上一轮画面分支提交，未合并 main。[源码 CI](https://github.com/ShengJunqi/hillside-archers/actions/runs/43504030836)成功。
- 原站发布 Sites 第 17 版，原生工具返回 `succeeded`，静态源码提交 `518e7b2706737cb2959e623f83cdd22b84f0820e`。保留原公开入口与访问方式。
- 备用站 `gh-pages` 最终提交 `7a83ae4a02edd249f1cfe567ea33202ce1462c45`，构建：https://github.com/ShengJunqi/hillside-archers/actions/runs/43504158521 。
- 对备用站 14 项产物逐一 HTTP 读取并比对 SHA-256：入口、渲染／场地／反馈模块、漫画 CSS、离线 HTML、两种字体、字体许可、公开云配置、DeepSeek 提示词、创意说明、源码 ZIP 和合作提示词，全部为 200 且与发布文件一致。字体与模块 MIME 正确。
- `npm test`、`npm run build`、`git diff --check` 通过。除原有规则／账号／输入回归外，增加双方整数弹道、选路、首领场景轮换、三类特殊 AI 意图、机关、震动衰减、多箭反馈和地形缓存检查。原生 Canvas 检查八种场地、角色近景与命中帧。
- 当前没有可调用的浏览器控制工具，尚未验证真实手机帧率和真实浏览器完整操作；原站以官方部署成功状态确认，独立 HTTP 字节核验在备用站完成。

本版字体由本站提供，离线 HTML 内嵌字体和完整许可，新增资源不需要字体 CDN、模型调用或后端资源。DeepSeek 仍为手动协作提示词，没有实际调用 harness。创意清单区分已实现与未来方案：https://shengjunqi.github.io/hillside-archers/comic-expedition-notes.txt 。

## 0.15.0 高清场景发布

- 游戏源码：`3998dc430a17f61ab6c8563fb763dd2a2e1b3df5`，PR：https://github.com/ShengJunqi/hillside-archers/pull/11 。[源码 CI](https://github.com/ShengJunqi/hillside-archers/actions/runs/43508041813)成功，未合并 main。
- 原站已发布 Sites 第 18 版，原生部署工具返回 `succeeded`；静态源码提交 `9d0e148b05d7ffdad47a9a9741913158cf4f6ffc`。沿用原公开地址与访问方式。
- 备用站 `gh-pages` 提交 `4fa381fc539083af1232b5d09e43d41fa09c5ddf`，已通过 [Pages 构建](https://github.com/ShengJunqi/hillside-archers/actions/runs/43508098829)。
- 备用站 16 项产物均 HTTP 200 且 SHA-256 与本机一致：页面、app／render／scenery 模块、漫画 CSS、离线 HTML、五张高清背景、土岩纹理、公开云配置、高清说明、源码 ZIP 和 DeepSeek 提示词。六项图片 MIME 为 image/webp。
- `npm test`、`npm run build`、`git diff --check` 通过；另外核对离线 HTML 内嵌六项图片的字节摘要与发布 WebP 一致，没有残留 art/ 外部图片请求。原账号配置、合作提示词和源码下载继续保留。
- 五张背景原始尺寸 1672×941，土纹 1254×1254；离线包约 4.19 MB。主站与离线版不调用图片生成服务。已用原生 Canvas 检查五种风格及竖屏画面，并补浅色箭／瞄准点的细深色边提高云层中的可读性。
- 浏览器控制入口不可调用，未宣称真实浏览器布局或手机 GPU 帧率验收。原站以官方部署成功状态确认，HTTP 字节核验在备用站完成。

主页和暂停菜单均有「场景风格」，默认随赛场变化，支持五种固定风格与本机记忆。详细范围：https://shengjunqi.github.io/hillside-archers/hd-scenery-notes.txt 。

## 0.16.0 战术地形与元素收尾发布

- 游戏源码：`e8199f952d595da13dfb00c49f784ddedd2c31fc`，PR：https://github.com/ShengJunqi/hillside-archers/pull/12 ，基于 `feat/hd-scenery`，未合并 main。[源码 CI](https://github.com/ShengJunqi/hillside-archers/actions/runs/43688076403)成功。
- 原站已发布 Sites 第 19 版，原生部署工具返回 `succeeded`；静态源码提交 `cc8c0869bdd75681041dee7cf38413676f68193a`。沿用原公开网址、账号配置、协作提示词与下载入口。
- 备用站 `gh-pages` 提交 `8716aed8a9231f86c0bfc8ce971169dd9d84dcf4`，已通过 [Pages 构建](https://github.com/ShengJunqi/hillside-archers/actions/runs/43688197000)。
- 备用站 21 项产物均 HTTP 200 且 SHA-256 与发布文件一致：入口、app／core／body／combat／encounters／bounties／render 模块、漫画 CSS、离线 HTML、公开云配置、六项 WebP、新版玩法说明、源码 ZIP、DeepSeek 提示词和原协作提示词。图片 MIME 为 `image/webp`。
- `npm run build`、`npm test`、`git diff --check` 通过；另以实际弹道检查十二种地形的 600 个击退后站位，均保留反击线路。回归覆盖动态肢体命中、坡面脚底接触、电脑力度规划、手机力度输入、角色技能／悬赏奖励和 KO 生命周期；原生 Canvas 检查高低地图、竖屏视角、倒地动作与元素收尾。
- 十二种实体坡形用于各模式，站距 520–1320、最大出生高差 240。新增持续击退、青松／磐石／灵雀选择、局内悬赏和重选，以及短元素 KO 收尾。没有新增运行时模型调用、后端资源或永久存档字段。
- 当前没有可调用的浏览器控制工具，尚未验收真实浏览器完整操作或手机 GPU 帧率。原站以官方部署成功状态确认，独立 HTTP 字节核验在备用站完成。

新版说明：https://shengjunqi.github.io/hillside-archers/tactical-terrain-notes.txt 。离线 HTML 约 4.24 MB，包含六项高清图片与字体许可，不依赖原站或外部图片服务。

## 0.16.1 扩展退让地面与弓箭射程

- 玩法源码提交 `f91205234bc7f0e2b9d644fcad7e534d772149e4`，发布源码 ZIP 对应含协作提示词更新的 `1f35ac87e2c9081fd5d32b44a7a4adad1b8f87a0`。PR：https://github.com/ShengJunqi/hillside-archers/pull/13 ，基于 `feat/tactical-terrain`，未合并 main。[源码 CI](https://github.com/ShengJunqi/hillside-archers/actions/runs/43788918838)成功。
- 原站已发布 Sites 第20版，官方部署返回 `succeeded`；静态源码提交 `1d74ec8d0dae581780a0cc72ecb3072fa645d3fd`。原公开访问方式、账号配置与下载入口继续保留。
- 备用站 `gh-pages` 提交 `fd0c6824441199558295bb3c016720b22e4d3bbb`，通过 [Pages 构建](https://github.com/ShengJunqi/hillside-archers/actions/runs/43788914613)。所有48个已跟踪发布文件均 HTTP 200 且 SHA-256 与本机发布文件一致，包括公开云配置、全部模块与图片、离线 HTML、源码 ZIP 和协作下载。
- 十二图原始出生坐标、初始距离、中央地形及掩体保留；两侧各补1000单位地面，真实世界为−1000..2600。箭速500→800，伤害和NPC保护预算保持原值。角色根节点、关节、投射物、补给、镜头及地表缓存共用实际边界。
- `npm run build`、完整 `npm test`、`git diff --check`通过。新增回归覆盖跨越旧边界的连续击退、起身／回合交接、新边缘反向脱离、最远两端真实弹道与AI、原始站距以及桌面／竖屏全景。原生 Canvas 导出并检查9个画面，修复高清背景露边、手机全景裁人和地表缓存下方黑条。
- 离线 HTML 为4,241,838字节；保持v2存档兼容，没有新增模型请求或后端资源。当前无可用浏览器控制入口，真实浏览器完整操作和手机GPU帧率尚未验收；原站以官方成功部署状态确认，独立文件字节核验在备用站完成。

## 0.17.0 星坠预瞄与炸弹助推

- 游戏源码及源码 ZIP：`18c4ab7e8e0a992cbb141373da543dd5fff7241c`；PR：https://github.com/ShengJunqi/hillside-archers/pull/14 ，基于 `fix/expanded-retreat-space`，未合并 main。[源码 CI](https://github.com/ShengJunqi/hillside-archers/actions/runs/43791566792)成功。
- 原站已发布 Sites 第21版，原生工具返回 `succeeded`；静态源码提交 `48bfad381078fa66699082369d6f66f11cb91336`。沿用原公开入口、账号配置及源码／协作下载。
- 备用站 `gh-pages` 提交 `fa322c1fbba4938a3eb0b757cedb5c06f3164417`，通过 [Pages 构建](https://github.com/ShengJunqi/hillside-archers/actions/runs/43791563144)。全部49个跟踪发布文件均 HTTP 200，SHA-256与本机发布文件一致，包括新技能说明、公开云配置、四个改动模块、离线 HTML、源码 ZIP、图片和协作文件。
- 星坠新增按住三分之一时间、真实预测线、整数方向调整及松开执行；伤害倍率1.25→1.45，星引扩大40单位拾球范围。引爆保留绑弹原箭，范围攻击后按瞬时速度×2、直接伤害×2继续飞行，额外一次穿障与一次地面跳弹；追加箭继承剩余状态，不重复助推。
- 完整 `npm test`、`npm run build`和`git diff --check`通过。新增280项核心、106项输入与82项渲染检查覆盖真实慢速、预测／命中、取消／焦点、穿球继承、一次跳弹、24箭限制和NPC保护。原生Canvas检查9个技能画面；离线单文件4,256,253字节，内联脚本编译检查通过。
- 存档格式、原始站距、扩展地图与NPC预算保留，没有新增后端资源或运行时模型请求。当前没有浏览器控制工具，未宣称真实浏览器操作或手机GPU帧率已验收。原站以官方部署成功确认，HTTP文件核验在备用站完成。

技能操作、具体继承规则与公开参考来源：https://shengjunqi.github.io/hillside-archers/active-bow-skills-notes.txt 。

## 0.17.1 无尽少补给与快节奏

- 游戏源码及源码 ZIP：`785727cb1b73fe78aae5a50d12d9ded75f67bd43`，PR：https://github.com/ShengJunqi/hillside-archers/pull/15 ，基于 `feat/active-bow-skills`，未合并 main。[源码 CI](https://github.com/ShengJunqi/hillside-archers/actions/runs/43793011093)成功。
- 原站发布 Sites 第22版，原生工具返回 `succeeded`；静态源码提交 `20de650fc33c096c9dbe4e4e5b32925ceb128c5c`。保留原公开入口、账号配置与协作下载。
- 备用站 `gh-pages` 提交 `89d5917bd3027c8c2bdfeda64da3bd594add486d`，通过 [Pages 构建](https://github.com/ShengJunqi/hillside-archers/actions/runs/43793006545)。
- 只调整无尽：每次行动最多补1球，场上最多4球，+1和爱心各最多2球；旧球4次行动后退场，防同回合重复生成。首次观察1.8秒、后续1秒，落箭后最短等待0.5秒，仍须等存活角色起身。单球回血、技能、悬赏、NPC预算及其他模式规则保持原值。
- 完整 `npm test`、`npm run build`、`git diff --check`通过；新增336项补给密度、过期／去重、真实节奏／恢复和模式隔离检查。离线 HTML 为4,257,095字节，最终内联脚本编译通过。
- 当前没有浏览器控制工具，未做真实浏览器／手机GPU验收；原站由官方成功部署状态确认。保留v2存档，没有新增后端资源或运行时模型请求。
- 备用站全部49个跟踪发布文件均 HTTP 200且SHA-256与发布文件一致，包括core、离线版、公开云配置、技能说明、源码ZIP及协作提示词。

## 0.18.0 有限特箭与隔关强化

- 游戏源码及源码 ZIP：`16e964053104bc94688615d31fd2ab4c59eac287`，PR：https://github.com/ShengJunqi/hillside-archers/pull/16 ，基于 `fix/rogue-pace`，未合并 main。[源码 CI](https://github.com/ShengJunqi/hillside-archers/actions/runs/43797451592)成功。
- 原站发布 Sites 第23版，原生工具返回 `succeeded`，静态源码提交 `f98b786fd61a86e854ba06f99ca1b9c830f880cf`。保留原公开网址、账号配置与协作／源码下载。
- 备用站 `gh-pages` 提交 `eb4e684850ed2a40310860f97d85599994fe35bf`，通过 [Pages 构建](https://github.com/ShengJunqi/hillside-archers/actions/runs/43797449012)。新纯模块 `relics.mjs` 与其他模块一并发布，离线版在core前内联该模块。
- 无尽特箭开局2份、每新关+1、上限5份；每整轮弓术扣1份，普通箭不限，取消不扣弹。每关保留选路与休息，仅第2／4／6关后选择强化；新的12项奖励池提高单次收益，加入回声落羽、元素引信、神射回收及破阵补弹，移出5项较弱选项但保留旧ID运算。
- `npm run build`、完整 `npm test`、`git diff --check`及最终离线脚本编译通过；离线 HTML 为4,270,270字节。新增纯函数、弹药／推进、实际应用DOM、遗物战斗、渲染与真实追击回归；中后期基准按隔关实际可获得的强化构筑验证。
- 发布前真实飞行审查发现初版落羽会被击退甩开，已改为连续、有速度上限的物理转向；十二地图×身体／头部瞄准×两名英雄共48次真实追击均命中，仍受掩体阻挡。手动特殊化后停止自动转向，保留预瞄真实性。原生Canvas检查7个遗物画面，并合并组合命中的重复文字。
- 弹药与新效果仅为局内状态，v2永久存档、NPC预算、原始站距与其他模式保留，没有新增后端资源或模型请求。当前没有可调用浏览器工具，未验收真实浏览器操作／手机GPU帧率；原站以官方成功部署状态确认。

新规则说明：https://shengjunqi.github.io/hillside-archers/ammo-relics-notes.txt 。

备用站最终51个跟踪发布文件均 HTTP 200，SHA-256与本机发布文件一致，包含新增relics模块、弹药说明、公开云配置、离线版和源码ZIP；一次静态模块503经单文件重试后通过。
